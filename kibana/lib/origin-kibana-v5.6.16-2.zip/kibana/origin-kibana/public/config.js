const config = {
  "logoutUrl": '/oauth/sign_out'
};
export default config
