const config = {
  "logoutUrl": '/auth/logout'
};
export default config
