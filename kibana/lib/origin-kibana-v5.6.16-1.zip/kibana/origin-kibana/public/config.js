const config = {
  "logoutUrl": '/oauth/sign_off'
};
export default config
