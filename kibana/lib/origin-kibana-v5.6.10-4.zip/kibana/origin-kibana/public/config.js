const config = {
  "logoutUrl": '/oauth/sign_in'
};
export default config
